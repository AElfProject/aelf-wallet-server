#!/bin/bash

DOCKER_ID=`docker ps |grep phpfpm | awk '{print $1}'`

sudo docker exec -it $DOCKER_ID /bin/bash -c 'supervisorctl start blockSync_aelf blockSync_tDVV elf-go getAllContracts mail_send market_chart message_push sys_message_push sys_message_queue transSync_aelf_0 transSync_tDVV_0 updateBalanceInit updateBalanceSig updateIndex updateTrans'

